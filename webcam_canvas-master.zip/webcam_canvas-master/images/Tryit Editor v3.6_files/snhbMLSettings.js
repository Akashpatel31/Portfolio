snhb.modules.machineLearning.mlSettings = {
	ts: 20200121174440,
	sidebar_sticky: {
		mean: 0.019186,
		dev: 0.015000
	},
	mid_content: {
		mean: 0.009681,
		dev: 0.015000
	},
	main_leaderboard: {
		mean: 0.050447,
		dev: 0.015000
	},
	wide_skyscraper: {
		mean: 0.059783,
		dev: 0.015000
	},
	try_it_leaderboard: {
		mean: 0.069727,
		dev: 0.015000
	},
	right_bottom_medium_rectangle: {
		mean: 0.009970,
		dev: 0.015000
	},
	bottom_medium_rectangle: {
		mean: 0.009929,
		dev: 0.015000
	},
};